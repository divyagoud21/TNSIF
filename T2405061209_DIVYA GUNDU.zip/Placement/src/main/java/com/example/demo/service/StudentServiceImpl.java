package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;
import com.example.demo.repository.StudentRepo;

@Service

public class StudentServiceImpl implements StudentService {

	
	@Autowired
	 private StudentRepo studentRepo;

	@Override
	public Student saveStudent(Student stu) {
		// TODO Auto-generated method stub
		 return studentRepo.save(stu);
	}

	@Override
	public List<Student> fetchStudentList() {
		// TODO Auto-generated method stub
		 return studentRepo.findAll();
	}

	@Override
	public Student fetchStudentById(Long id) {
		// TODO Auto-generated method stub
		  return studentRepo.findById(id).get();
	}

	@Override
	public void deleteStudentById(Long id) {
		// TODO Auto-generated method stub
		  studentRepo.deleteById(id);
	   
	}

	@Override
	public Student updateStudent(Long id, Student stu) {
		// TODO Auto-generated method stub
		
		Student stuDB=studentRepo.findById(id).get();

	       if(Objects.nonNull(stu.getName()) &&
	       !"".equalsIgnoreCase(stu.getName())) {
	    	   stuDB.setName(stu.getName());
	       }

	       if(Objects.nonNull(stu.getCollege()) &&
	    	       !"".equalsIgnoreCase(stu.getCollege())) {
	    	    	   stuDB.setCollege(stu.getCollege());
	    	       }
	       
	       
	       if(Objects.nonNull(stu.getQualification()) &&
	    	       !"".equalsIgnoreCase(stu.getQualification())) {
	    	    	   stuDB.setQualification(stu.getQualification());
	    	       }
	       
	       if(Objects.nonNull(stu.getCourse()) &&
	    	       !"".equalsIgnoreCase(stu.getCourse())) {
	    	    	   stuDB.setCourse(stu.getCourse());
	    	       }
	       
	       if(Objects.nonNull(stu.getCertificate()) &&
	    	       !"".equalsIgnoreCase(stu.getCertificate())) {
	    	    	   stuDB.setCertificate(stu.getCertificate());
	    	       }
	       
	       if(Objects.nonNull(stu.getRoll()) &&
	    	       !"".equalsIgnoreCase(stu.getRoll())) {
	    	    	   stuDB.setRoll(stu.getRoll());
	    	       }
	       
	       if(Objects.nonNull(stu.getHallTicketNo()) &&
	    	       !"".equalsIgnoreCase(stu.getHallTicketNo())) {
	    	    	   stuDB.setHallTicketNo(stu.getHallTicketNo());
	    	       }
	       if(Objects.nonNull(stu.getYear()) &&
	    	       !"".equalsIgnoreCase(stu.getYear())) {
	    	    	   stuDB.setYear(stu.getYear());
	    	       }     

	     return studentRepo.save(stuDB);
	}

	
	
	
	
   

}
